include_recipe 'openfire_v4::service'

Chef::Log.info('====> Executing config recipe <======')
