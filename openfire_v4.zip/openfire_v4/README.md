Videri cookbooks
=================

Openfire cookbook
