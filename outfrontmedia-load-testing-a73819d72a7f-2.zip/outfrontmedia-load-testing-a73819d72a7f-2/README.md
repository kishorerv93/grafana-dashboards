Load Testing
====

This project contains automated load tests for VLE.


JMeter tests
-----

See *jMeter Instructions* section below for jMeter installation and config.


### **`canvas_happy.jmx`**

Covers the most frequent calls that a player (a.k.a
canvas, liveboard, board) sends to the system during normal operations.

TODO: add REST login calls (0.1% of the calls or once every 100 threads)

TODO: add REST GET player calls (4% or once every 2.5 threads)

TODO: add REST GET ticker (0.7% or about once every ten threads)

TODO: add REST playback_reporter_batch (20% or twice per thread)

TODO: add REST player_logstash_batch (8% or once per thread)

**Notes**:





#### Required properties

To run this test, the following jmeter properties must be set

* `app_id`: App id for app authentication (oauth)
* `app_secret`: App secret
* `stack_id`: the name of the stack to target (e.g: 'load', 'dev', 'qa2')
* `dataset_file_index`: the index of the csv set to use (e.g: 4 for **`data/device_ids_4.csv`**)


### **`canvas_setup.jmx`**

uses `data/device_ids.csv` to pre-provision 100K devices on a stack


#### Required properties

To run this test, the following jmeter properties must be set

* `app_id`: App id for app authentication (oauth)
* `app_secret`: App secret
* `stack_id`: the name of the stack to target (e.g: 'load', 'dev', 'qa2')


### jMeter Setup Instructions


#### 1. Set Up

**Port `1099`** must be open, as jMeter server client communication happens via RMI,
and that is the standard port assigned to rmiregistry.

**Step 1** Clone the VLE load-testing project and build the docker image:

```sh
$ git@git.videri.com:vle/load-testing.git
$ cd load-testing
$ docker build . -t jmeter
```

**Properties**

You can set these to configure your test runs. They can be set via the command line when starting
your server (e.g: `-J` or `--jmeterproperty` flag) or in the properties files (e.g:**`user.properties`**)

For more info, take a look at *[Apache JMeter Properties Customization Guide][properties guide]*


#### 2 Run jMeter

Using Docker:


```sh
$ docker run -d -P --name server1 -v /path/to/local/log/dir/:/jmeter_log -v `pwd`/jMeter/:/jmeter_tests jmeter {jmeter command}
```

Replace `jmeter command` with one of the commands below.


##### 2A. Run a server

**Step 1**: Each server requires a unique set of 5000 device ids to work with.
Copy **`jMeter/device_ids_00000-99999.csv`** to **`jMeter/device_ids.csv`**.
Truncate the new file to contain only 5000 device ids.
Keep the first line with `BLANK_FOR_SETUP_THREAD`.

**Step 2**: Run jmeter server commands

To run a server with verbose debug mode and max 25G heap size. Hostname needs to be set so
Java RMI does not to use the machine hostname property.

```sh
-e "JVM_ARGS=-Xmx25G" jmeter -Djava.rmi.server.hostname={public IP} --server
```

logging: `jmeter -j /jmeter_log/server1.log`

In order to avoid committing secrets in projects the user is required to set them via command line.
It looks like this:

```sh
jmeter -t test.jmx -Gapp_id={app_id} -Gapp_secret={app_secret}
```

If necessary, the RMI registry port can be configured:

```sh
-e "SERVER_PORT=9010" jmeter -Djava.rmi.server.hostname={public IP} -Dserver.rmi.localport=9000 -Dserver.rmi.port=9010
```

For debugging purposes, we can add some verbosity to the logs:

```sh
jmeter -Djava.rmi.server.hostname={public IP} -Djava.rmi.server.logCalls=true -LDEBUG --server
```


###### Example

A Server:

```sh
$ docker run -it --rm -v `pwd`/jMeter:/jmeter_tests jmeter -e "JVM_ARGS=-Xmx25G" \
  jmeter --server \
  --jmeterproperty app_id=a11223344 \
  --jmeterproperty app_secret=44552211b \
  --jmeterproperty stack_id=load \
  --jmeterproperty dataset_file_index=2 \
  --jmeterlogfile log/jmeter.log \
  --logfile log/results.log \
  --systemproperty java.rmi.server.logCalls=true \
  --systemproperty java.rmi.server.hostname=10.2.2.219 \
  --systemproperty server.rmi.localport=60000
```


##### 2B. Run client


If you are running the client on your workstation that is not accessible by the servers,
you can open ssh reverse tunnels on each server machine.

```sh
ssh -i ~/.ssh/development.pem -R 60000:localhost:60000 ubuntu@{server machine IP}
```


###### Example

```sh
$ docker run -it --rm --name jmeterClient -v $HOME/docker_mnt/:/jmeter_log -v `pwd`/jMeter/:/jmeter_tests jmeter \
  jmeter --nongui --testfile canvas_happy.jmx \
    --systemproperty java.rmi.server.hostname=172.17.0.3 \
    --systemproperty client.rmi.localport=60000 \
    --remotestart 172.17.0.2 \
    --jmeterlogfile /jmeter_log/client_j.log \
    --logfile jMeter/results/client_l.log
```


#### Reading list

* https://www.blazemeter.com/blog/nine-easy-solutions-jmeter-load-test-%E2%80%9Cout-memory%E2%80%9D-failure

* https://stackoverflow.com/questions/16618915/setting-up-jmeter-for-distributed-testing-in-aws-with-connectivity-issues#32260139

* https://askubuntu.com/questions/162229/how-do-i-increase-the-open-files-limit-for-a-non-root-user#162230

* https://askubuntu.com/questions/464755/how-to-install-openjdk-8-on-14-04-lts#464894

* https://gerardnico.com/wiki/jmeter/remote

[properties guide]: https://www.blazemeter.com/blog/apache-jmeter-properties-customization

### jMeter AWS Load-Test Environment

The AWS load-test environment is administrated in OpsWorks here:  https://console.aws.amazon.com/opsworks/home?region=us-east-1#/stack/0e7f8f02-d430-43c7-8963-b7b41884ca79/stack

The stack contains a jMeter master client instance as well as jMeter server slaves.

#### Setting Up the Test

1. `ssh -A jmeter-client`
1. If it's the first time running the tests then: `git clone git@git.videri.com:vle/load-testing.git`
1. `cd load-testing/jMeter`
1. `bin/start-servers -i <vle app id> -s <vle app secret> <list of jmeter server hosts>`
    1. Note:  Due to a configuration issue (VR-10192), the jMeter server process on each jmeter-server-n 
    instance must be started by this script at least once to ensure that the process maximum open files 
    limit is not set to 4096.
1. `bin/config-vle [-a <# agents per VLE>] [-s <# shards per agent>] <list of VLE hosts>`
    1. Configures the setup of Agents across the load-test VLE instances by allocating
    a configurable number of roster shards to a configurable number of Agent instances.  For instance, if the stack
    has 5 VLE instances and the load target is 100K XMPP endpoints then 4 agents per VLE instance @ 5 shards per agent
    covers the 100 roster shard default.
    1. After this script is run, all Agents are stopped which is what we want while the entire
    fleet of canvases comes online.  Otherwise, the VLE system is flooded with online events that propagate 
    via the MessageBus to various services causing performance issues.
1. `bin/remote-exec 'sudo service openfire restart' <list of Openfire hosts>`
    1. Restarts Openfire servers to ensure that their max open file limits are high.
1. `bin/remote-exec 'sudo stop crm_reporter' <list of VLE hosts>`
    1. Live-ops complains that they receive a lot of alerts from load-test stack.  Stop reporter services
    for now.
1. `bin/remote-exec 'sudo -H -u deploy bash -c "cd /srv/www/central/current; RAILS_ENV=production bundle exec rake player:offline"' <a VLE host>`
    1. Efficiently resets all Player.online_status DB entries to "offline".
1. Ensure that stack setting `openfire.opts` has the correct Java heap setting of `-Xms5632m -Xmx5632m`.
    1. TODO:  Get Dev-ops to permanently change this setting.  Too large and the OS does not have enough RAM left
    to allocate the required number of sockets.
     
#### Running the Test

1. `/usr/local/apache-jmeter-3.3/bin/jmeter -n -t canvas_happy.jmx -Djava.rmi.server.hostname=10.2.1.238 -Dclient.rmi.localport=60000 -R10.2.2.209 -j log/jmeter.log -l log/results.log`
    1. Note the list of jMeter server IPs in the `-R` argument.
    
There are two supported test projects:
1. `canvas_happy.jmx` - The main load test that applies HTTP and XMPP traffic.  Includes the behaviour of `canvas_xmpp_only.jmx`
plus HTTP and XMPP load.
1. `canvas_xmpp_only.jmx` - Not a test per se, but useful to set up a large number of XMPP connects in order to try out 
Agent-related solutions under load.

Before running the test, consider the # canvases and the ramp-up time that is to be used.

| jMeter Instance Size | Java Heap (MB) | Max # XMPP Endpoints Achieved |
|----------------------|----------------|----------------------|
| m4.large             | 5550           | 3800                 |
| m4.xlarge            | 12288          | 8000                 |

The following configuration was used to achieve  100K connected XMPP endpoints in the simple 'canvas_xmpp_only`:

| Configuration | Value |
|---------------|-------|
| # threads     | 8000  |
| # ramp-up     | 7200s |
| # jMeter servers | 13 x m4.xlarge|
| # Openfire | 5 m4.large |
| # VLE      | 5 m4.large |
| # agents per VLE | 4 |
| # shards per agent | 5 |
| # roster shards | 100 |

Notes on how these configuration values were determined can be found in the "Test 3 results" here: https://videri.atlassian.net/wiki/spaces/SD/pages/210042907/Openfire+load+tests+with+Agent+Sharding

To observe the number of sessions supported by the Openfire cluster, browse to `Server / Clustering` page in the Openfire Admin.
Note that the `Sessions` page will time out once there are more than ~5K sessions, so it cannot be used during the load test.

Once the desired number of stable XMPP connections are established, it is time to start the Agents.  Doing so will cause Openfire
to fire a Presence event per XMPP endpoint to an Agent.  The Agent enqueues the event onto the `player.presence` AMPQ exchange.
Central consumes these published events and updates Players' online_status property via a write to the Postgres DB.  The Agents also
fire the presence event through established web-sockets.  